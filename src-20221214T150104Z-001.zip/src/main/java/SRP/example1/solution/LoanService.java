package SRP.example1.solution;

/**
 * Created by jubair.
 * Date: 28/8/22
 * Time: 6:16 PM
 */

public class LoanService {
    public void getLoanInterestInfo(String loanType){
        if(loanType.equals("homeLoan")){
            // implementation
        }
        if(loanType.equals("personalLoan")){
            // implementation
        }
        if(loanType.equals("car")){
            // implementation
        }
    }
}
