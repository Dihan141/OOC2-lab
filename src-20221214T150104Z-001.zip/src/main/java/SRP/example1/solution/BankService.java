package SRP.example1.solution;

/**
 * Created by jubair.
 * Date: 28/8/22
 * Time: 6:18 PM
 */

public class BankService {
    public long deposit(long amount, String accountNumber) {
        // deposit amount   balance += amount
        return 0;
    }

    public long withdraw(long amount, String accountNumber) {
        // withdraw amount if possible      balance -= amount
        return 0;
    }
}
