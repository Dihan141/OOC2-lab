package SRP.example1.solution;

/**
 * Created by jubair.
 * Date: 28/8/22
 * Time: 6:16 PM
 */

public class PrinterService {
    public void printPassbook(String accountNumber){
        // update transaction info in passbook
    }
}
