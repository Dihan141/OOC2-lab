package other.hudai;

/**
 * Created by jubair.
 * Date: 24/10/22
 * Time: 9:59 PM
 */

public class Calculator {
    public int multiply(int a, int b){
        return a * b;
    }

    public String simpleMessage(){
        return "Hi";
    }
}
