package other.generics;

/**
 * Created by jubair.
 * Date: 12/9/22
 * Time: 7:45 AM
 */

public class Faculty extends Person{
    public Faculty(String firstName, String lastName) {
        super(firstName, lastName);
    }
}
