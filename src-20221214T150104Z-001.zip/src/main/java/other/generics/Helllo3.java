package other.generics;

/**
 * Created by jubair.
 * Date: 23/9/22
 * Time: 12:01 PM
 */

public class Helllo3 extends Human{
    Helllo3(int age) {
        super(age);
    }
}
