package other.generics;

/**
 * Created by jubair.
 * Date: 12/9/22
 * Time: 7:32 AM
 */

public class ArrayList <E>{
    public void add(E element) {
    }
    public E get(int index){
        E ele = null;
        return ele;
    }
}
