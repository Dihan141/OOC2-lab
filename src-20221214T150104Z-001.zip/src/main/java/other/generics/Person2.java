package other.generics;

/**
 * Created by jubair.
 * Date: 23/9/22
 * Time: 11:42 AM
 */

public class Person2 extends Human{
    public Person2(int age){
        super(age);
    }
}
