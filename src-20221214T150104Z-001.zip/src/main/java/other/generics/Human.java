package other.generics;

/**
 * Created by jubair.
 * Date: 23/9/22
 * Time: 11:41 AM
 */

public class Human {
    int age;
    Human(int age){
        this.age = age;
    }
}
