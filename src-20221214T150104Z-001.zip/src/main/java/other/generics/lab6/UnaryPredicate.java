package other.generics.lab6;

/**
 * Created by jubair.
 * Date: 19/9/22
 * Time: 8:50 PM
 */

public interface UnaryPredicate<T> {
    public boolean test(T obj);
}
