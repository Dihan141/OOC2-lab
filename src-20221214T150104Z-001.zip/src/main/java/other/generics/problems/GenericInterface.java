package other.generics.problems;

/**
 * Created by jubair.
 * Date: 3/11/22
 * Time: 11:15 AM
 */

public interface GenericInterface<T> {
    T compare(T a, T b);
}
