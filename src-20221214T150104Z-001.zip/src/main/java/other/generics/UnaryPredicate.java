package other.generics;

/**
 * Created by jubair.
 * Date: 13/9/22
 * Time: 7:28 AM
 */

public interface UnaryPredicate<T> {
    public boolean test(T obj);
}
