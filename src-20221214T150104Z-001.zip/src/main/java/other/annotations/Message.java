package other.annotations;

import java.lang.annotation.Documented;

/**
 * Created by jubair.
 * Date: 4/11/22
 * Time: 10:02 AM
 */

@Documented
public @interface Message {
    String greeting();
}
