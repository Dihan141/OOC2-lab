package other.annotations;

/**
 * Created by jubair.
 * Date: 5/11/22
 * Time: 7:34 PM
 */

public class Animal {
    public void sayWhatDoYouWant(){
        System.out.println("I want to eat");
    }
}
