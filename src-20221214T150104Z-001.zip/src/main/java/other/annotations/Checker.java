package other.annotations;

/**
 * Created by jubair.
 * Date: 5/11/22
 * Time: 7:53 PM
 */

@FunctionalInterface
public interface Checker {
    boolean check();
}
