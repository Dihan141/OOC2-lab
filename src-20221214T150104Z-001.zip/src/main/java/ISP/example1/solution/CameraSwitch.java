package ISP.example1.solution;

/**
 * Created by jubair.
 * Date: 18/10/22
 * Time: 6:08 AM
 */

public interface CameraSwitch{
    void turnCameraOn();
    void turnCameraOff();
}
