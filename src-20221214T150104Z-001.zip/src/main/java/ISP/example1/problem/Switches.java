package ISP.example1.problem;

/**
 * Created by jubair.
 * Date: 18/10/22
 * Time: 6:05 AM
 */

interface Switches {
    void startEngine();
    boolean turnRadioOn();
    void turnRadioOff();
    void turnCameraOn();
    void turnCameraOff();
}
