package ISP.example2.solution;

/**
 * Created by jubair.
 * Date: 28/8/22
 * Time: 7:38 PM
 */

public class CannonMG implements IPrint, IScan{
    @Override
    public void printContent(String content) {

    }

    @Override
    public void scanContent(String content) {

    }

    @Override
    public void photoCopyContent(String content) {

    }
}
