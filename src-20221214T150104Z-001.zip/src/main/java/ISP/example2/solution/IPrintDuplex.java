package ISP.example2.solution;

/**
 * Created by jubair.
 * Date: 28/8/22
 * Time: 7:38 PM
 */

public interface IPrintDuplex {
    public void printDuplexContent(String content);
}
