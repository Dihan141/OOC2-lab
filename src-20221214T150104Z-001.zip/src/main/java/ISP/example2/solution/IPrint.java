package ISP.example2.solution;

/**
 * Created by jubair.
 * Date: 28/8/22
 * Time: 7:37 PM
 */

public interface IPrint {
    public void printContent(String content);
    public void photoCopyContent(String content);
}
