package ISP.example2.problem;

/**
 * Created by jubair.
 * Date: 28/8/22
 * Time: 7:32 PM
 */

public class CannonMG implements IPrintTasks{
    @Override
    public void printContent(String content) {

    }

    @Override
    public void scanContent(String content) {

    }

    @Override
    public void faxContent(String content) {
        // not applicable
    }

    @Override
    public void photoCopyContent(String content) {

    }
}
