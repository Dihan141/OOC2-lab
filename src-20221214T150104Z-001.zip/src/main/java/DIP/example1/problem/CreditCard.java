package DIP.example1.problem;

/**
 * Created by jubair.
 * Date: 28/8/22
 * Time: 7:01 PM
 */

public class CreditCard {
    public void doTransaction(long amount){
        System.out.println("Payment using Credit Card");
    }
}
