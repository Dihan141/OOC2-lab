package DIP.example1.problem;

/**
 * Created by jubair.
 * Date: 28/8/22
 * Time: 7:02 PM
 */

public class DebitCard {
    public void doTransaction(long amount){
        System.out.println("Payment using Debit Card");
    }
}
