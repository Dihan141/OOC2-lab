package DIP.example1.solution;

/**
 * Created by jubair.
 * Date: 28/8/22
 * Time: 7:07 PM
 */

public interface BankCard {
    public void doTransaction(long amount);
}
