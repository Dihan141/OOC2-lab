package DIP.example2.solution2;

/**
 * Created by jubair.
 * Date: 23/9/22
 * Time: 7:48 AM
 */

public class Printer {
    void print(Document html){
        // printing
    }
}
