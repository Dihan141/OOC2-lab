package LSP.example1.solution;

/**
 * Created by jubair.
 * Date: 28/8/22
 * Time: 6:42 PM
 */

public interface SocialMedia {
    public void chatWithFriend();

    public void sendPhotosAndVideos();
}
