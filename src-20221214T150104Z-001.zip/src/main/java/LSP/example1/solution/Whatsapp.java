package LSP.example1.solution;

/**
 * Created by jubair.
 * Date: 28/8/22
 * Time: 6:46 PM
 */

public class Whatsapp implements SocialMedia, SocialVideoCallManager{
    @Override
    public void chatWithFriend() {

    }

    @Override
    public void sendPhotosAndVideos() {

    }

    @Override
    public void groupVideoCall(String... users) {

    }
}
