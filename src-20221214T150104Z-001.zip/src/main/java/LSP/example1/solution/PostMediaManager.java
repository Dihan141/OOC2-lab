package LSP.example1.solution;

/**
 * Created by jubair.
 * Date: 28/8/22
 * Time: 6:44 PM
 */

public interface PostMediaManager {
    public void publishPost(Object post);
}
