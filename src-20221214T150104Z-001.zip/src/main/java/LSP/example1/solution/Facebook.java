package LSP.example1.solution;

/**
 * Created by jubair.
 * Date: 28/8/22
 * Time: 6:47 PM
 */

public class Facebook implements SocialMedia, PostMediaManager, SocialVideoCallManager{
    @Override
    public void publishPost(Object post) {

    }

    @Override
    public void chatWithFriend() {

    }

    @Override
    public void sendPhotosAndVideos() {

    }

    @Override
    public void groupVideoCall(String... users) {

    }
}
