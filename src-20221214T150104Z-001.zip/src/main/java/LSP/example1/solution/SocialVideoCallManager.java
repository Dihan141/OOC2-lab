package LSP.example1.solution;

/**
 * Created by jubair.
 * Date: 28/8/22
 * Time: 6:43 PM
 */

public interface SocialVideoCallManager {
    public void groupVideoCall(String... users);
}
