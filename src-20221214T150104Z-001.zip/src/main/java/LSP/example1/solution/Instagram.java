package LSP.example1.solution;

/**
 * Created by jubair.
 * Date: 28/8/22
 * Time: 6:45 PM
 */

public class Instagram implements SocialMedia, PostMediaManager {
    @Override
    public void publishPost(Object post) {

    }

    @Override
    public void chatWithFriend() {

    }

    @Override
    public void sendPhotosAndVideos() {

    }
}
