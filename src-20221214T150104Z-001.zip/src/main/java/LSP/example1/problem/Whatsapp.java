package LSP.example1.problem;

/**
 * Created by jubair.
 * Date: 28/8/22
 * Time: 6:40 PM
 */

public class Whatsapp extends SocialMedia{
    @Override
    public void chatWithFriend() {

    }

    @Override
    public void publishPost(Object post) {
        // Not Applicable   however we have to implement this.
        // throw exception or null
    }

    @Override
    public void sendPhotosAndVideos() {

    }

    @Override
    public void groupVideoCall(String... users) {

    }
}
