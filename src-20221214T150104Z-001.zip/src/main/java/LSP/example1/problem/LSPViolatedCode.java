package LSP.example1.problem;

/**
 * Created by jubair.
 * Date: 28/8/22
 * Time: 6:50 PM
 */

public class LSPViolatedCode {
    public void communicate(SocialMedia socialMedia){
        socialMedia.publishPost("Hudai");
    }
}
