package LSP.example1.problem;

/**
 * Created by jubair.
 * Date: 28/8/22
 * Time: 6:39 PM
 */

public class Instagram extends SocialMedia {
    @Override
    public void chatWithFriend() {

    }

    @Override
    public void publishPost(Object post) {

    }

    @Override
    public void sendPhotosAndVideos() {

    }

    @Override
    public void groupVideoCall(String... users) {
        // Not Applicable
    }
}
