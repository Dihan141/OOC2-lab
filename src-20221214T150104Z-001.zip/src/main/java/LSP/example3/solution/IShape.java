package LSP.example3.solution;

/**
 * Created by jubair.
 * Date: 8/9/22
 * Time: 3:16 PM
 */

public interface IShape {
    int area();
}
