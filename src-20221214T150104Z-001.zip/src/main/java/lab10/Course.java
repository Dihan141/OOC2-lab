package lab10;

/**
 * Created by jubair.
 * Date: 8/11/22
 * Time: 9:30 AM
 */

public class Course {
    String code;
    String name;
    double credit;
}
