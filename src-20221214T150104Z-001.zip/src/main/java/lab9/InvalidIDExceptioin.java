package lab9;

/**
 * Created by jubair.
 * Date: 29/10/22
 * Time: 12:49 PM
 */

public class InvalidIDExceptioin extends Exception {
    public InvalidIDExceptioin(String message) {
        super(message);
    }
}
