package lab9;

/**
 * Created by jubair.
 * Date: 3/11/22
 * Time: 11:54 PM
 */

@ClassPreamble(author = "jubair", date = "03/11/2022", currentVersion = 2, lastModified = "jubair", reviewers = {"ajaira", "manush"})
public class AnnotationTest {
}
