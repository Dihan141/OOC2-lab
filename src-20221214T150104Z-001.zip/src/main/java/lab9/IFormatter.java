package lab9;

import java.io.File;
import java.util.List;

/**
 * Created by jubair.
 * Date: 1/11/22
 * Time: 10:12 AM
 */

public interface IFormatter {
    File format(List<Student> list);
}
