package OCP.example4.solution;

/**
 * Created by jubair.
 * Date: 10/10/22
 * Time: 7:16 PM
 */

public enum DegreeType {
    RegularThesis, RegularNonThesis, Executive
}
