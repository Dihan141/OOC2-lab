package OCP.example3.solution;

/**
 * Created by jubair.
 * Date: 10/10/22
 * Time: 9:29 PM
 */

public enum VehicleType {
    SEDAN, MOTOR_BIKE, SEVEN_SEATER
}
