package OCP.example3.solution;

/**
 * Created by jubair.
 * Date: 8/9/22
 * Time: 11:13 AM
 */

public interface IVehicle {
    int perHeadFare();
    boolean canTakeTrip();
}
